import React from 'react';

const App = () => {
  return (
    <div>
      Todo App을 만들자!
    </div>
  );
};

export default App;