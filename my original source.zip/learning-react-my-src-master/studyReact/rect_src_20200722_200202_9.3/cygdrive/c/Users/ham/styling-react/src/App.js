import React, { Component } from 'react';
import CSSModule from './CSSModule';

class App extends Component {
  render() {
    return ( 
      <div>
        <CSSModule />
      </div>
    );
  }
}

export default App;
