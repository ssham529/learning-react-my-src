import React from "react";
import Say from "./Say";

const App = () => {
  return (
    <Say />
  );
};

export default App;
