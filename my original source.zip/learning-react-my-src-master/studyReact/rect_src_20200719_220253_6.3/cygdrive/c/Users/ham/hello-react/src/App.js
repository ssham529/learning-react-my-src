import React, { Component } from "react";
import IterationSample from "./IterationSample";

class App extends Component {
  render () {
    return (
      <IterationSample />
    );
  }

};

export default App;
 