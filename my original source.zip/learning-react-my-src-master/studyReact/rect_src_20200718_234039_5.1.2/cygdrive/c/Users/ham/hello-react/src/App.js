import React from "react";
import ValidationSample from "./ValidationSample";

const App = () => {
  return (
    <ValidationSample />
  );
};

export default App;
