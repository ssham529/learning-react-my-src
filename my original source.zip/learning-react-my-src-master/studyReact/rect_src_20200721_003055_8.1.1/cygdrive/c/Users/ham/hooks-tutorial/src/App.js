import React from 'react';
import Info from './Info';

const App = () => {
  return <Info />;
}

export default App; 